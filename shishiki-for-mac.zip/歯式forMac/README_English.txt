Shishiki for Mac (version 1.2)
==============================

A small tool that puts Palmer (Zsigmondy) cross dental notation on one line
in Excel, Word, PowerPoint, Numbers, Pages and Keynote. It runs in your web browser; the only thing
you install is one font.


Setup (once)

1. Double-click "ShishikiCross.ttf" and click "Install Font".
   (Font Book may show a warning in the validation report; you can ignore it.)
2. If Excel is open, quit it (Cmd+Q) and open it again.


How to use

1. Open "歯式forMac.html" (Safari or Chrome). Use the "English" button at the
   top right to switch the language.
2. Choose a mark, then click teeth:
     6   plain
     (6) circle (e.g. bridge abutment)
     ◎   double circle
     ⦶   circle with vertical line
     ⊗   circle with cross
     △   triangle
   Click the same tooth again with the same mark to remove it.
   Primary teeth (A-E) are supported. You can add a label (Br, Crown, ...)
   in front of the notation, or type your own.
3. Click "Copy" and paste.
   - Excel, Word: just paste.
   - PowerPoint, Keynote, Pages, Numbers: after pasting you'll see Latin
     letters. Select them and change the font to "ShishikiCross".
   If you see boxes, the font isn't installed or another font is used.

   Next group ... keep the current notation and start another one after it
   C .......... clear the current teeth and label
   AC ......... clear everything

   Other formats ("Excel 2 lines", "Text 1 line") work without the font.


Notes

- To open the Excel file on another computer, install the font there too.
  Otherwise the notation is shown as boxes.
- Excel's formula bar shows other characters. This is expected.
- Updating from 1.0: reinstall the font. Notation entered with 1.0 still displays.
- Tested on Mac. The font should also work on Windows (right-click the .ttf
  and choose "Install"), but this has not been confirmed yet.


Terms of use

- Free to use, including in clinics. Documents you create are yours to use.
- No modification, redistribution or resale without the author's permission.
  See "利用規約.txt" (Japanese and English).
- The digit and letter shapes of ShishikiCross are based on DejaVu Sans, so
  the font file follows "フォントのライセンス（DejaVu）.txt".
- No warranty. Always check what you write in patient records yourself.
